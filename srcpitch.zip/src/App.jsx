import { useState } from 'react'
import './App.css'
import Home from './pages/Home'
import Teams from './pages/Teams'
import Player from './pages/Player'
import { BrowserRouter, Routes, Route } from 'react-router-dom'


function App() {
  
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/teams" element={<Teams />} />
                <Route path="/player" element={<Player />} />
                
            </Routes>
        </BrowserRouter>

    )
  
}

export default App
